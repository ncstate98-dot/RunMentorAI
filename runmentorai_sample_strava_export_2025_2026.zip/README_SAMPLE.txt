RunMentorAI Sample Strava Export

This archive is a privacy-sanitized demonstration dataset derived from a Strava export structure.
It contains synthetic names, identifiers, dates, GPS routes, profile data, and gear data.
The activity distances and durations are retained in approximate historical form so RunMentorAI can demonstrate importing and analyzing a realistic running history.

This file is not an official Strava sample and is provided only for evaluating RunMentorAI.
